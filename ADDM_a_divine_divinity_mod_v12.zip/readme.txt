WARNING!
Please backup your original divine divinity install before you install this mod! Your savegames are NOT compatible. You WILL have to start over. So finish your playthrough and install the mod after. Or you can delete your savegame and install the mod. Also delete all files in dynamic folder before you start


installation:
the directory is set up to just drop the whole divine_divinity folder in. Its the same layout and structure as all divine divinity installs.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
This is for players who want more of a Diablo experience. The game has been made tougher, so you can't cheese your way through. Some areas and enemies will be tougher so you have to take your time and have real strategies instead of walking over just about every enemy type you come in contact with. Don't get ganged up on, use your summons to destract, always have an exit and make sure you can match the fight they are putting out. Save often, especially on lar's bone which is going to be brutal. All the difficulties will have more enemies overall so perhaps start on normal or easy and get a feel before you jump into the "mosh pit" difficulties. Aleroth should give you plenty of resources to start with even without stealing, check all the houses. There should be enough choices for players in the beginning, wether you want to sneak around, hunt from afar or go in blades swinging, you can now play the way you want to.


V1.2
monsters:
1. There are more of them: in the aleroth forest (mostly orcs, small spiders and snakes, 2 drummers at the upper corners, a few heavies sprinkled about), catacombs (mostly a lot of trash tier, a few higher level enemies added in last 2 lower levels), sewers (just a few more spiders), orc camp and everywhere mercenaries are, their numbers were doubled. 
2. fights have been added: Outside the mitox's camp toward orc camp, wastelands (a lot of fights between orcs and imps have broke out, try to not get caught in the middle)

levels: some monsters have higher levels, resistances and/or armor/attack. 
1. Patriarc has the highest level and stats in the game (Patriarc is the top God in the game). 
2. Demon of lies will be a lot tougher (level 75, armor really high (same as duke janus who is level 59), resistances 100, 1 point increase in base protection and attack. 
3. Black Ring top wizards are level 50 and resistances 75 first encounter, 2nd encounter level 60, high armor, resistances 100.
4. Deathknights levels been increased, boss red deathknight level 50, boss gold deathknight level 55, poison weakness reduced
5. heavy orcs (the toughest) have a slight boost in stats to make them more competitive in wastelands against the imps.
6. human soldiers, mitox and alex get a 1 level increase, knights (like seth) are level 45 (mostly so they wont get overwhelmed on lars bone).
7. gregor brock tweaked to be stronger so he wont die so easily.

items:
1. mithril (atleast some of them do) armor now has intelligence requirements (60 in this case)
2. starting loot in house above Joram's home has perma fixed stats to ensure it wont be broken or garbage. This equipment is a whole tier above what you get from george (including stealing) and is special. it is decent equipment without being cheaty, plus there is more than enough gold and potions for the beginning grind.


Aleroth update:
1. minor tweaks to aleroth to ensure paths are not blocked where there is decor items like grass. Put more reasonable starting equipment, better than what George sells but still lower tier. it has custom stats on some of the pieces, strength requirements dropped to 10 so all players can use.


overall maps update:
1. more enemies added in: catacombs, aleroth forest, orc camp, sewers (just a little more extra spiders).
2. aleroth forest tweaked to look better overall.
3. ars magica has been beautified. Some decor items near ars magica roads (like the dig site and coffins) have been moved slightly to increase room.
4. tweaked the look of a road into mitox camp (cover up dissimiliar ugly texture seams)
5. tweaked poor quarters to hide ugly texture seams that were present in the stock game.
6. verdistis floor and grass textures fixed (dirt instead of floor or grass), removed annoying boxes covering hatch to georges killer.
7. dark forest imp and warrior castle textures fixed (tiled interiors instead of groung), farm gate around enterence to elven village (makes sure monsters have a harder time entering on lars bone) and elven burial grounds (help keeps orcs out. Bridge added to the right of enterence to elven village to get across the stream and visit the unaccessable house (not sure if there is perma darkness over there or not), if you cant walk across, throw your teleporter stones across the bridge).


Wastelands update:
1. added more and a greater variety of enemies
2. orcs are present and can be seen in pockets fighting for their lives outside of the town.
3. smiruk is here with his magical axe. Don't bother him, hes fighting for his life and will attack on sight like all orcs that were added.
4. extra decor and statues added next to black ring enterence.

skills changes:
1. divine death major boost
2. magical barrier (resistances) doubled
3. burn damage major boost
4. chain lightning moderate boost
5. explode moderate boost
6. monster identification in increments of 20 per level
7. all forms of strength and blessing boosted and now have the same and increased duration
8. time stop duration minor increase
9. meteor shower large boost
10. hardened wall 10 level boost per skill level
11. shield spells protection major boost level 5=500
12. magic shield spell protection major boost level 5=500
13. elemental strike minor boost
14. hardened wall increases steel skeleton level in 10 level increments making them more useful late game
15. summoned rat hitpoints major increase (hey, when you need a distraction to get away you will thank me)
16. discs damage moderate boost 
17. augment damage increases in 3's (level 1=3 level 5=15)
18. poison damage increased overall
19. upgraded many (if not all) the arrow skills so they wont be complete garbage
20. spiritual damage minor increase
21. curse skill offense and defense loss levels 2 and 4 upgraded so now leveling them up actually does something and is not a waste of points

---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

to uninstall:
hope you made a backup of your divine divinity folder like I mentioned earlier in this readme, ModDB, and Larian forums.


resources here:


https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945336

https://github.com/Raan/DDEditor.2

https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945264&#Post945264

https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945264#Post945264