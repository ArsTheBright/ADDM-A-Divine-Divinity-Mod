WARNING!
Please backup your original divine divinity install before you install this mod! Your savegames are NOT compatible. You WILL have to start over. So finish your playthrough and install the mod after. Or you can delete your savegame and install the mod. Also delete all files in dynamic folder before you start


installation:
the directory is set up to just drop the whole divine_divinity folder in. Its the same layout and structure as all divine divinity installs.

-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
V1.1
Aleroth update:
1. Aleroth gains a new farm above otho's house, minor additions to aleroth. Put the flower pot back by jake's wife's grave.
2. minor tweaks to aleroth beauty.
3. skeleton in mardaneous's cellar moved to catacombs

overall map update:
1. small groups of orcs that did not challenge the player were incorperated into aleroth forest and dr. elrath cave
2. some spare soldiers moved to help solders fighting orcs inside mitox camp
3. fixed a ton of interior tiles I must have broke when fixing the floors in both world0 and world4 now interiors work as designed.

Wastelands update:
1. all buildings now have flooring that fits the enviroment.
2. more buildings added to wastelands to make it look more believable that this is the orc homeland.
3. orc related decor has been added to show that orcs do in fact dwell here, also to help make it easier to find the orc town by putting well spaced orc flags near their walls.
4. ruins outside of town arent as numerous so this makes them feel more significant and easier to tell where you are at.
5. enemies placed out of bounds moved into playable area.
6. loot and decor moved out of bounds moved to playable area.
7. a little bit of new decor and adjustment of black ring snake cave.
8. a few dead bodies placed in points of interest outside of town.
9. orc town now has roads so you will know where to go to get to the buildings and wont get lost.

skills changes:
1. wisdom experience boost now much more valuable level  5% through level 5: 25%
2. divine death random damage minor boost
3. burn damage minor boost
4. chain lightning moderate boost
5. explode moderate boost
6. hell spikes moderate boost (it sucked a lot before, now its a good early skill, lategame skills are still better)
7. skeleton level gets a boost 10 level increments per level gain
8. meteor strike moderate boost (should make it more viable for low level players)
9. meteor shower large boost
10. hardened wall level 4 and 5 level boost to make them less trash tier in late game playthroughs
11. banish boosted moderately
12. elemental strike minor boost
13. crossbow recuperation time reduction doubled (read a lot the crossbow skill sucked, hopefully this should help decently)
14. mace damage increased
15. hammer recuperation time reduced
16. discs damage minor boost (should make them more useful for low level players)
17. augment damage level 1-3 doubled (level 4-5 remains the same)
18. poison potions small, normal and large slight damage increase
19. charm enemy duration increased slightly
20. frost duration reduced (it gets spammed too much holding enemies in place with no chance to attack, causes glitching with death animations especially with deathblow).
21. stun duration reduced (it gets spammed too much holding enemies in place with no chance to attack, causes glitching with death animations especially with deathblow).
---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

to uninstall:
hope you made a backup of your divine divinity folder like I mentioned earlier in this readme, ModDB, and Larian forums.


resources here:


https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945336

https://github.com/Raan/DDEditor.2

https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945264&#Post945264

https://forums.larian.com/ubbthreads.php?ubb=showflat&Number=945264#Post945264